/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ado.pkg1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class Gravaçao {
    
    // Variaveis 
    private static final float[] totalRegioes = new float[6];
    private static int index = 0; 
    
    
    public static void criarArquivoTxt(){
    
 /*      ------------------------------------- */
 /*      Escrita em arquivo                    */
 /*      ------------------------------------- */
        String arquivoDeSaida = "saida.txt";

        try {

            FileWriter fileWriter = new FileWriter(arquivoDeSaida);

            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Gravando em arquivo na ordem que os dados foram inseridos no vetor
            bufferedWriter.write("pib da regiao Norte = "+totalRegioes[0]);
            bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Nordeste = "+totalRegioes[1]);
            bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Sudeste = "+totalRegioes[2]);
            bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Sul = "+totalRegioes[3]);
            bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Centro-Oeste = "+totalRegioes[4]);

            // fecha o arquivo
            bufferedWriter.close();
        }
        catch(IOException ex) {
            System.out.println("Erro de escrita em '" + arquivoDeSaida + "'");
        } 
    }
    
    // Metodo armazena o valor passado pela classe de leitura.
    // index controla os indices do vetor. 
    public static void escritaEmArquvo (float valor){
    
        totalRegioes [index] = valor;  
        index++;
       
    }
    
    
}
