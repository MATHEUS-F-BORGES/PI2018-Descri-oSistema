/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ado.pkg1;

import java.io.*;

/**
 * Class Description . . .
 *
 * @author: Matheus F Borges
 * @version: 1.0 Main Class File: topAXX.java File: Structure.java
 * Date:19/08/2018
 */
public class Leitura {

    public static void main(String[] args) {
        System.out.println("*********************************************");
        // Variaveis
        String pib = "pib.txt";
        String linha = null;
        String[] estados = null;

        /*      ------------------------------------- */
 /*      Abertura de arquivo e loop de leitura */
 /*      ------------------------------------- */
        try {
            FileReader fileReader = new FileReader(pib);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // loop por cada linha do arquivo
            while ((linha = bufferedReader.readLine()) != null) {

                estados = linha.split(";");
                Capturar.armazenarDigitos(estados);
                Capturar.armazenarEstados(estados);
            }

            // fecha o arquivo
            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Arquivo inexistente: '" + pib + "'");
        } catch (IOException ex) {
            System.out.println("Erro lendo o arquivo '" + pib + "'");
        }

        // Apos ler o arquivo pib, armazena cada cidade e digitos em vetores  
        String[] exibirEstados = Capturar.retornarEstados();
        float[] exibirDigitos = Capturar.retornarDigitos();
        // variavel total recebe a soma do pib de todas cidades.
        float total = Capturar.retornarTotal();

        for (int i = 0; i < exibirEstados.length; i++) {

            System.out.println(exibirEstados[i] + " | "
                    + (exibirDigitos[i] * 100) / total + " %");
        }
        System.out.println("*********************************************");

        String regioes = "regioes.txt";

        try {
            FileReader fileReader2 = new FileReader(regioes);

            BufferedReader bufferedReader2 = new BufferedReader(fileReader2);

            while ((linha = bufferedReader2.readLine()) != null) {

                Capturar.armazenarRegioes(linha);

                if (linha.equals("")) {

                    float regiao;
                    regiao = Capturar.retornarTotalDaRegiao();
                    Gravaçao.escritaEmArquvo(regiao);
                    Capturar.setTotalDaRegiao(0);
                }

            }

            bufferedReader2.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Arquivo inexistente: '" + regioes + "'");
        } catch (IOException ex) {
            System.out.println("Erro lendo o arquivo '" + regioes + "'");
        }

        Gravaçao.criarArquivoTxt();

    }

}
